﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace dolgozatmzs
{
    class Bolygok
    {
        public string Bolygo { get; set; }
        public int HoldSzam { get; set; }
        public double TerfogatF { get; set; }

        public Bolygok(string sor)
        {
            var v = sor.Split(';');
            Bolygo = v[0];
            HoldSzam = int.Parse(v[1]);
            TerfogatF = double.Parse(v[2]);
        }

        public override string ToString() 
        {
            return $"{Bolygo}{HoldSzam}{TerfogatF}";        
        }
    }
    class Program
    {

        static void atlag(List<Bolygok> a)
        {
            double osszeg = 0;
            for (int i = 0; i < a.Count; i++)
            {
                osszeg = osszeg + (a[i].HoldSzam / a.Count);
            }


            Console.WriteLine($"3.2: a naprendszerben egy bolygónak átlagosa {osszeg}");
        }
        static void legnygyobbterfogat(List<Bolygok> t)
        {
            double legnterfogat = t[0].TerfogatF;
            string legnterfogatnev = t[0].Bolygo;
            for (int i = 1; i < t.Count; i++)
            {
                if (t[i].TerfogatF > legnterfogat)
                {
                    legnterfogat = t[i].TerfogatF;
                    legnterfogatnev = t[i].Bolygo;
                }
            }
            Console.Write($"3.3: A legnagyobb térfogatú bolygó a {legnterfogatnev}");
        }
        static void Main(string[] args)
        {
            
            Console.ForegroundColor = ConsoleColor.Green;
            var bolygok = new List<Bolygok>();
            foreach (var item in File.ReadAllLines(@"..\..\..\solsys.txt"))
            {
                bolygok.Add(new Bolygok(item));
            }

            foreach (var item in bolygok)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n3. feladat");
            Console.WriteLine($"3.1: {bolygok.Count} Bolygó van a naprendszerben");
            atlag(bolygok);
            legnygyobbterfogat(bolygok);


            Console.Write("\n3.4 Írd be a keresett bolygó nevet: ");
            string nev = Console.ReadLine();

            bool van = false;
            int i = 0;
            while (i < bolygok.Count && !van)
            {
                if (nev == bolygok[i].Bolygo)
                {
                    van = true;
                }
                i++;
                
            }
            if (van)
            {
                Console.WriteLine($"Van ilyen keresett bolygó név ({nev})");
            }
            else
            {
                Console.WriteLine("Sajnos nincs ilyen bolygó a naprendszerben");
            }
        }
    }

}

